<?php   
    require_once 'exercicio68.php';
    require_once 'exercicio69.php';

    interface IAnimalOrcamento extends IAnimal{
        public function orcamentoGastosAnimal(): ItemOrcamentoComplexo;
    } 

    class AnimalOrcamento implements IAnimalOrcamento{
        private Animal $animal;
        private ItemOrcamento $orcamento;

        public function __construct(Animal $animal, ItemOrcamento $orcamento){
            $this->animal = $animal;
            $this->orcamento = $orcamento;
        }

        public function getNomeEspecie():String{
            return $this->animal->getNomeEspecie();
        }

        public function getNomeAnimal():String{
            return $this->animal->getNomeAnimal();
        }

        public function orcamentoGastosAnimal(): ItemOrcamentoComplexo{            
            if($this->orcamento->getHistorico() === 'vacina W'){
                return new ItemOrcamentoComplexo($this->orcamento->getHistorico(), $this->orcamento->getValor(), Array( $this->orcamento));
            }
            // return new ItemOrcamentoComplexo();
        }
    }

    function gastos(Array $animaisOrcamento):Array{
        $gastos = [];
        foreach($animaisOrcamento as $animalOrcamento){
            $gastos[] = $animalOrcamento->orcamentoGastosAnimal();
        }
        return $gastos;
    }

    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal1, new ItemOrcamento('vacina X', 100));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal2, new ItemOrcamento('vacina Y', 90));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal3, new ItemOrcamento('vacina Z', 100));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal4, new ItemOrcamento('vacina W', 400));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal5, new ItemOrcamento('vacina W', 450));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal6, new ItemOrcamento('vacina X', 200));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal7, new ItemOrcamento('vacina Z', 100));
    $listaAnimaisOrcamento[] = new AnimalOrcamento($animal8, new ItemOrcamento('vacina W', 400));
    
    var_export(gastos($listaAnimaisOrcamento));
    
    
    

